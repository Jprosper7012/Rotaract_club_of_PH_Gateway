// Shared browser-safe event presentation helpers; no database imports.
import type { ClubEvent, EventStatus } from "./events";
export type { ClubEvent, EventStatus };

function localDateKey(value: string | Date | number): string {
  const parts = new Intl.DateTimeFormat("en-CA", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: "Africa/Lagos" }).formatToParts(new Date(value));
  return `${parts.find((part) => part.type === "year")!.value}-${parts.find((part) => part.type === "month")!.value}-${parts.find((part) => part.type === "day")!.value}`;
}

export function getStatus(event: Pick<ClubEvent, "isCampaign" | "dateNeedsConfirmation" | "eventDate">, today: string): EventStatus {
  if (event.isCampaign) return "Campaign";
  if (event.dateNeedsConfirmation) return "Date to confirm";
  if (!event.eventDate) return "Date to be announced";
  return localDateKey(event.eventDate) < today ? "Past event" : "Upcoming";
}

export function dateLabel(value: string | null, short = false, sourceLabel?: string | null) {
  return value ? new Intl.DateTimeFormat("en-GB", { day: "numeric", month: short ? "short" : "long", year: "numeric", timeZone: "Africa/Lagos" }).format(new Date(value)) : sourceLabel ?? "Date to be announced";
}

export function eventDateLabel(event: Pick<ClubEvent, "eventDate" | "sourceDateLabel" | "isCampaign">, short = false) {
  return dateLabel(event.eventDate, short, event.sourceDateLabel ?? (event.isCampaign ? "Ongoing awareness campaign" : null));
}

export function eventLink(event: Pick<ClubEvent, "slug" | "id">) { return `/events/${event.slug ?? event.id}`; }
export function todayInLagos() { return localDateKey(Date.now()); }
