import { db } from "@/db";
import { events } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { cache } from "react";

export type EventRecord = typeof events.$inferSelect;
export type ClubEvent = Omit<EventRecord, "eventDate" | "createdAt"> & { eventDate: string | null; createdAt: string | null };
export type EventStatus = "Upcoming" | "Past event" | "Campaign" | "Date to confirm" | "Date to be announced";

export function serializeEvent(event: EventRecord): ClubEvent {
  return { ...event, eventDate: event.eventDate?.toISOString() ?? null, createdAt: event.createdAt?.toISOString() ?? null };
}

export const getEvents = cache(async () => (await db.select().from(events).orderBy(desc(events.eventDate))).map(serializeEvent));
export const getEvent = cache(async (identifier: string) => {
  if (!identifier || identifier.length > 160 || (/^\d+$/.test(identifier) && (!Number.isSafeInteger(Number(identifier)) || Number(identifier) > 2147483647))) return null;
  const clause = /^\d+$/.test(identifier) ? eq(events.id, Number(identifier)) : eq(events.slug, identifier);
  const [event] = await db.select().from(events).where(clause).limit(1);
  return event ? serializeEvent(event) : null;
});
