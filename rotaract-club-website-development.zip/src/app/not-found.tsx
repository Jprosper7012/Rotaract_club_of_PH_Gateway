import Link from "next/link";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";

export default function NotFound() {
  return <><Navbar /><main id="main-content" className="container-club py-24 text-center"><p className="text-[#a70942] tracking-[3px] text-xs font-semibold mb-5">404 · A LITTLE OFF THE PATH</p><h1 className="heading mb-6">Let’s find your way back.</h1><p className="text-sm text-stone-500 leading-relaxed mb-8">This page or event could not be found.<br />There are still plenty of good things to explore.</p><Link href="/events" className="btn-club">Explore our events <Icon name="arrow" size={15} /></Link></main><Footer /></>;
}
