import Link from "next/link";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";
import EventBrowser from "@/components/event-browser";
import { getEvents } from "@/lib/events";
import { todayInLagos } from "@/lib/event-display";

export const dynamic = "force-dynamic";
export const metadata = { title: "Events & initiatives", description: "Explore the Rotaract Club of Port Harcourt Gateway’s fellowships, leadership celebrations, health conversations, and partner service initiatives." };

export default async function EventsPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const [events, params] = await Promise.all([getEvents(), searchParams]);
  return <><Navbar /><main id="main-content"><div className="container-club breadcrumb-club"><Link href="/">Home</Link><Icon name="chevron" size={11} /><span>Events & initiatives</span></div><section className="page-intro"><div className="container-club page-intro-inner"><div><div className="eyebrow">Our events & initiatives</div><h1>Come for the friendship.<br /><em>Stay for the impact.</em></h1><p>Every gathering is a chance to connect, give back, and grow. Discover our club activities and the partner initiatives that bring us together.</p></div><div className="intro-aside"><strong>{String(events.length).padStart(2, "0")}</strong><p>events & initiatives<br />One shared purpose.</p></div></div></section><section className="container-club" aria-label="Browse club events"><EventBrowser events={events} today={todayInLagos()} initialStatus={params.status} /></section></main><Footer /></>;
}
