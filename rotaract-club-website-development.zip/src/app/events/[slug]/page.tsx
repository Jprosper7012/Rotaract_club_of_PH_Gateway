import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";
import EventCard, { StatusTag } from "@/components/event-card";
import { EventRegistration, ShareEvent } from "@/components/event-actions";
import { getEvent, getEvents } from "@/lib/events";
import { eventDateLabel, getStatus, todayInLagos } from "@/lib/event-display";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getEvent((await params).slug);
  return { title: event?.title ?? "Event not found", description: event?.shortDescription ?? "Explore our club events." };
}

export default async function EventDetailPage({ params }: Props) {
  const event = await getEvent((await params).slug);
  if (!event) notFound();
  const today = todayInLagos();
  const status = getStatus(event, today);
  const related = (await getEvents()).filter((item) => item.id !== event.id).sort((a, b) => Number(b.category === event.category) - Number(a.category === event.category)).slice(0, 3);
  const original = event.imageUrl?.startsWith("/uploads/");
  const hasProjectAlbum = ["read-to-rise", "enisc-bee-2"].includes(event.slug ?? "");
  const confirmationMessage = event.eventDate ? "Numeric date from flyer · confirmation needed" : "The flyer does not state a year · confirmation needed";

  return <><Navbar /><main id="main-content"><div className="container-club breadcrumb-club"><Link href="/">Home</Link><Icon name="chevron" size={11} /><Link href="/events">Events</Link><Icon name="chevron" size={11} /><span>{event.title}</span></div>
    <section className="page-intro"><div className="container-club detail-title"><div className="flex items-center gap-4"><span className="eyebrow">{event.category}</span><StatusTag status={status} /></div><h1 className="heading">{event.title}</h1><p>{event.theme}</p></div></section>
    <div className="container-club detail-layout"><div><img className="detail-image" src={event.imageUrl ?? "/events/inaugural-fellowship.svg"} alt={`${original ? "Supplied flyer" : "Adapted web artwork"} for ${event.title}`} width="900" height="700" /><p className="art-credit">{original ? "Original event flyer supplied by the club." : "Adapted web artwork · Event details transcribed from the supplied flyer."}</p><article className="detail-copy"><h2>{event.isCampaign ? "A shared commitment to change" : event.category === "Remembrance" ? "In loving memory" : "About this event"}</h2>{event.description.split("\n\n").map((paragraph, index) => <p key={index} style={{ whiteSpace: "pre-line" }}>{paragraph}</p>)}{event.sourceNote && <div className={`source-note ${event.dateNeedsConfirmation ? "source-warning" : ""}`}><Icon name="info" size={17} /><div>{event.dateNeedsConfirmation && <strong className="block mb-1">Please confirm the date with the club</strong>}{event.sourceNote}</div></div>}<h2 style={{ marginTop: 30 }}>Organisers & partners</h2><p><strong style={{ color: "var(--ink)" }}>{event.organizer}</strong>{event.partners && <><br />{event.partners}</>}</p>{hasProjectAlbum && <Link href={`/gallery?event=${event.slug}`} className="link-club"><Icon name="image" size={16} /> View the project gallery <Icon name="arrow" size={15} /></Link>}</article></div>
      <aside className="detail-sidebar" aria-label="Event information"><h2>{event.isCampaign ? "Campaign information" : "The details"}</h2><div className="detail-fact"><Icon name="calendar" size={20} /><div><small>{event.isCampaign ? "Schedule" : "Date"}</small><p>{eventDateLabel(event)}{event.dateNeedsConfirmation && <span className="block text-amber-700 text-[10px] mt-1">{confirmationMessage}</span>}</p></div></div>{event.timeLabel && <div className="detail-fact"><Icon name="clock" size={20} /><div><small>Time · West Africa Time</small><p>{event.timeLabel} WAT</p></div></div>}{event.location && <div className="detail-fact"><Icon name={event.location.includes("Online") ? "video" : "pin"} size={20} /><div><small>{event.location.includes("Online") ? "Platform" : "Venue"}</small><p>{event.location}</p>{!event.location.includes("Online") && <a className="link-club" style={{ fontSize: 10, marginTop: 8 }} href={`https://maps.google.com/?q=${encodeURIComponent(event.location)}`} target="_blank" rel="noreferrer">View on map <Icon name="diagonal" size={12} /></a>}</div></div>}
      <div className="detail-actions">{status === "Upcoming" ? <EventRegistration eventId={event.id} /> : <><Link href={`/contact?subject=${encodeURIComponent(event.dateNeedsConfirmation ? `Date confirmation: ${event.title}` : `Event inquiry: ${event.title}`)}`} className="btn-club">{event.dateNeedsConfirmation ? "Confirm the event date" : "Get involved with the club"}<Icon name="arrow" size={14} /></Link>{status === "Past event" && <p>This date has passed. Contact us about our next activities.</p>}</>}{event.eventDate && !event.dateNeedsConfirmation && <a className="btn-club btn-outline" href={`/api/events/${event.slug ?? event.id}/calendar`}><Icon name="calendar" size={15} /> Download calendar event</a>}<ShareEvent />{event.imageUrl && <a href={event.imageUrl} download={`${event.slug ?? "event"}${original ? "-flyer.jpg" : "-web-artwork.svg"}`} className="link-club justify-center mt-2"><Icon name="download" size={14} /> {original ? "Download flyer" : "Download web artwork"}</a>}</div></aside>
    </div><section className="section-club" style={{ borderTop: "1px solid var(--line)", background: "#fff" }}><div className="container-club"><div className="section-top"><div><div className="eyebrow">Keep exploring</div><h2 className="heading">More ways we come together.</h2></div><Link href="/events" className="link-club">All events <Icon name="arrow" size={15} /></Link></div><div className="events-grid">{related.map((item) => <EventCard key={item.id} event={item} today={today} />)}</div></div></section>
  </main><Footer /></>;
}
