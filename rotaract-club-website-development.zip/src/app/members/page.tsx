import Link from "next/link";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { members } from "@/db/schema";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import MemberCard from "@/components/member-card";
import Icon from "@/components/icon";

export const dynamic = "force-dynamic";
export const metadata = { title: "Our people", description: "Meet the club leaders named in the Rotaract Club of Port Harcourt Gateway’s leadership handover materials." };

export default async function MembersPage() {
  const leaders = await db.select().from(members).where(eq(members.isActive, true)).orderBy(members.id);
  return <><Navbar /><main id="main-content"><div className="container-club breadcrumb-club"><Link href="/">Home</Link><Icon name="chevron" size={11} /><span>Our people</span></div><section className="page-intro"><div className="container-club"><div className="eyebrow">The people behind the purpose</div><h1>Leadership through service.<br /><em>Friendship at the heart.</em></h1><p>Celebrating the people who help our club grow, connect, and create lasting impact.</p></div></section><section className="section-club container-club"><div className="grid md:grid-cols-2 gap-7">{leaders.map((member) => <MemberCard key={member.id} {...member} />)}</div><div className="source-note mt-7"><Icon name="info" size={16} /><p>Leadership names and Rotary Year roles follow the supplied Handing Over Ceremony flyer. No unverified member photographs or personal contact details are published.</p></div><div className="invite-banner"><div><h2>There’s room for your story, too.</h2><p>Find your community, develop your leadership, and put your ideas into action.</p></div><Link href="/contact?subject=Membership" className="btn-club">Become a member <Icon name="arrow" size={15} /></Link></div></section></main><Footer /></>;
}
