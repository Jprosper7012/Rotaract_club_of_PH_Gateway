import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Rotaract Club of Port Harcourt Gateway",
    template: "%s | Rotaract Club of Port Harcourt Gateway",
  },
  description:
    "Rotaract Club of Port Harcourt Gateway - A service organization for young leaders dedicated to making a difference through service, fellowship, and leadership development.",
  keywords: [
    "Rotaract",
    "Rotaract Club",
    "Port Harcourt",
    "Rivers State",
    "Nigeria",
    "Service",
    "Youth Leadership",
    "Community Service",
  ],
  authors: [{ name: "Rotaract Club of Port Harcourt Gateway" }],
  openGraph: {
    title: "Rotaract Club of Port Harcourt Gateway",
    description:
      "Service Above Self - Join us in making a difference in Port Harcourt.",
    type: "website",
    locale: "en_NG",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
