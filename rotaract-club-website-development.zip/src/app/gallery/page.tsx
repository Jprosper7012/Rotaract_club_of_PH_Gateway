import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { events, gallery } from "@/db/schema";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";
import GalleryBrowser from "@/components/gallery-browser";

export const dynamic = "force-dynamic";
export const metadata = { title: "Our gallery", description: "Explore artwork from our club events and partner initiatives, with credits and project information." };

export default async function GalleryPage({ searchParams }: { searchParams: Promise<{ event?: string }> }) {
  const [items, params] = await Promise.all([db.select({ id: gallery.id, title: gallery.title, imageUrl: gallery.imageUrl, caption: gallery.caption, kind: gallery.kind, credit: gallery.credit, eventSlug: events.slug, eventTitle: events.title }).from(gallery).leftJoin(events, eq(gallery.eventId, events.id)).orderBy(desc(gallery.createdAt), gallery.id), searchParams]);
  const hasPhotos = items.some((item) => item.kind === "photo");
  return <><Navbar /><main id="main-content"><div className="container-club breadcrumb-club"><Link href="/">Home</Link><Icon name="chevron" size={11} /><span>Our gallery</span></div><section className="page-intro"><div className="container-club page-intro-inner"><div><div className="eyebrow">Our gallery</div><h1>A shared purpose.<br /><em>A story worth sharing.</em></h1><p>The ideas, invitations, and initiatives that bring our community together. Take a closer look at the stories behind each event.</p></div><div className="intro-aside"><Icon name="image" size={49} style={{ color: "var(--club)" }} /><p>Our people. Our purpose.<br />Our shared story.</p></div></div></section><section className="section-club container-club"><GalleryBrowser items={items} initialEvent={params.event} />{!hasPhotos && <div className="source-note" style={{ marginTop: 30 }}><Icon name="info" size={16} /><p>These event covers are web adaptations of the supplied club materials, not original flyers or outreach photographs. Open an item for its organiser credits and event details.</p></div>}</section></main><Footer /></>;
}
