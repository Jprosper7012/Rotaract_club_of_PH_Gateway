"use client";

import { useState, type FormEvent } from "react";
import Icon from "@/components/icon";

export function ContactForm({ initialSubject = "General inquiry" }: { initialSubject?: string }) {
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [error, setError] = useState("");
  const subjects = ["General inquiry", "Membership", "Partnership", "Event sponsorship", "Other"];
  if (!subjects.includes(initialSubject)) subjects.unshift(initialSubject);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const form = e.currentTarget; const data = new FormData(form);
    setStatus("sending"); setError("");
    try {
      const response = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: data.get("name"), email: data.get("email"), subject: data.get("subject"), message: data.get("message"), website: data.get("website") }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? "Unable to send your message. Please try again.");
      form.reset(); setStatus("success");
    } catch (err) { setError(err instanceof Error ? err.message : "Unable to send your message. Please try again."); setStatus("error"); }
  }
  if (status === "success") return <div className="form-success"><Icon name="check" size={40} /><h3>Thank you for reaching out.</h3><p role="status">Your message has been saved for the club. We’re glad you want to connect.</p><p style={{ marginTop: 12, fontSize: 10 }}>No automatic email confirmation is sent. You can also reach the club through @rcphgateway.</p><button type="button" className="btn-club btn-outline mt-6" onClick={() => setStatus("idle")}>Send another message</button></div>;
  return <form className="form-club" onSubmit={submit}><h2>Let’s start a conversation.</h2><p>Membership, partnerships, or simply saying hello—we’d love to hear from you.</p><div><label htmlFor="contact-name">Full name <span aria-hidden="true">*</span></label><input id="contact-name" name="name" required minLength={2} maxLength={160} autoComplete="name" placeholder="Your full name" /></div><div><label htmlFor="contact-email">Email address <span aria-hidden="true">*</span></label><input id="contact-email" name="email" type="email" required maxLength={255} autoComplete="email" placeholder="you@example.com" /></div><div><label htmlFor="contact-subject">What’s on your mind?</label><select id="contact-subject" name="subject" defaultValue={initialSubject}>{subjects.map((subject) => <option key={subject}>{subject}</option>)}</select></div><div><label htmlFor="contact-message">Your message <span aria-hidden="true">*</span></label><textarea id="contact-message" name="message" required minLength={10} maxLength={5000} rows={5} placeholder="Tell us a little about how you’d like to get involved..." /></div><div style={{ display: "none" }} aria-hidden="true"><label htmlFor="website">Leave this field empty</label><input id="website" name="website" tabIndex={-1} autoComplete="off" /></div><button type="submit" className="btn-club" disabled={status === "sending"}>{status === "sending" ? "Sending your message..." : "Send message"}<Icon name="arrow" size={16} /></button>{status === "error" && <p role="alert" className="form-error">{error}</p>}<p style={{ fontSize: 10 }}>Your details are stored only to respond to your inquiry.</p></form>;
}
