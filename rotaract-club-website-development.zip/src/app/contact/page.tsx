import Link from "next/link";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";
import { ContactForm } from "./ContactForm";

export const metadata = { title: "Get in touch", description: "Connect with the Rotaract Club of Port Harcourt Gateway about membership, events, and partnerships." };

export default async function ContactPage({ searchParams }: { searchParams: Promise<{ subject?: string }> }) {
  const { subject } = await searchParams;
  return <><Navbar /><main id="main-content"><div className="container-club breadcrumb-club"><Link href="/">Home</Link><Icon name="chevron" size={11} /><span>Get in touch</span></div><section className="page-intro"><div className="container-club"><div className="eyebrow">Let’s connect</div><h1>Good things start<br /><em>with a conversation.</em></h1><p>Bring an idea, ask a question, or take your first step into the Rotaract family.</p></div></section><div className="container-club contact-layout"><div className="contact-info"><h2>There’s a place for you here.</h2><p>Whether you’re interested in becoming a member, joining an initiative, or working with us on a project, we’d love to connect.</p><div className="detail-fact"><Icon name="pin" size={23} /><div><small>Our community</small><p>Port Harcourt, Rivers State<br />Nigeria</p></div></div><div className="detail-fact"><Icon name="instagram" size={23} /><div><small>Follow & message us</small><a href="https://www.instagram.com/rcphgateway/" target="_blank" rel="noreferrer" className="link-club">@rcphgateway <Icon name="diagonal" size={13} /></a><p className="mt-2">Instagram & Facebook</p></div></div><div className="detail-fact"><Icon name="calendar" size={23} /><div><small>Meet us at an event</small><p>Check each event page for its venue and time.<br />Contact us for our next fellowship arrangements.</p><Link href="/events" className="link-club mt-3">Explore events <Icon name="arrow" size={13} /></Link></div></div><div className="source-note"><Icon name="people" size={18} /><p>Where friendships meet service.<br /><strong>E1B1 — Each one, bring one.</strong></p></div></div><div className="contact-card"><ContactForm initialSubject={subject?.slice(0, 255)} /></div></div></main><Footer /></>;
}
