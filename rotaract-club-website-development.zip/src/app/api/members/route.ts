import { db } from "@/db";
import { members } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const profiles = await db.select({ id: members.id, name: members.name, position: members.position, bio: members.bio, imageUrl: members.imageUrl }).from(members).where(eq(members.isActive, true)).orderBy(members.id);
    return Response.json({ members: profiles });
  } catch (error) { console.error("Unable to load public club profiles:", error); return Response.json({ error: "Unable to load club profiles." }, { status: 500 }); }
}
