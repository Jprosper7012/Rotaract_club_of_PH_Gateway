import { db } from "@/db";
import { gallery } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const galleryItems = await db.select().from(gallery).orderBy(gallery.createdAt);
    return Response.json({ gallery: galleryItems });
  } catch (error) {
    console.error("Error fetching gallery:", error);
    return Response.json({ error: "Failed to fetch gallery" }, { status: 500 });
  }
}
