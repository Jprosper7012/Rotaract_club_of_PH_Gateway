import { db } from "@/db";
import { eventRegistrations } from "@/db/schema";
import { getEvent } from "@/lib/events";
import { getStatus, todayInLagos } from "@/lib/event-display";

export const dynamic = "force-dynamic";
export async function POST(request: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const raw = await request.text();
    if (raw.length > 6000) return Response.json({ error: "Submission too large." }, { status: 413 });
    let body: unknown; try { body = JSON.parse(raw); } catch { return Response.json({ error: "Please submit valid JSON." }, { status: 400 }); }
    if (!body || typeof body !== "object" || Array.isArray(body)) return Response.json({ error: "A name and email are required." }, { status: 400 });
    const fields = body as Record<string, unknown>;
    const name = typeof fields.name === "string" ? fields.name.trim() : "";
    const email = typeof fields.email === "string" ? fields.email.trim().toLowerCase() : "";
    if (name.length < 2 || name.length > 160 || email.length > 255 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "Enter a valid full name and email address." }, { status: 400 });
    const event = await getEvent((await params).slug);
    if (!event) return Response.json({ error: "Event not found." }, { status: 404 });
    if (getStatus(event, todayInLagos()) !== "Upcoming") return Response.json({ error: "Registration is only available for confirmed upcoming events. Contact the club for more information." }, { status: 409 });
    const saved = await db.insert(eventRegistrations).values({ eventId: event.id, name, email }).onConflictDoNothing({ target: [eventRegistrations.eventId, eventRegistrations.email] }).returning({ id: eventRegistrations.id });
    return Response.json({ ok: true, alreadyRegistered: saved.length === 0 }, { status: saved.length ? 201 : 200 });
  } catch (error) { console.error("Event registration failed:", error); return Response.json({ error: "We couldn’t save your interest. Please try again later." }, { status: 500 }); }
}
