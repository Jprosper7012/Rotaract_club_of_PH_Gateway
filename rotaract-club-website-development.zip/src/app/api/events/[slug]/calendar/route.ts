import { getEvent } from "@/lib/events";

export const dynamic = "force-dynamic";
const escape = (value: string) => value.replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
const stamp = (date: Date) => date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
function fold(line: string) {
  const segments: string[] = []; let segment = ""; let length = 0;
  for (const char of line) { const size = Buffer.byteLength(char, "utf8"); if (length + size > 73) { segments.push(segment); segment = ""; length = 0; } segment += char; length += size; }
  segments.push(segment); return segments.join("\r\n ");
}

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const event = await getEvent((await params).slug);
  if (!event) return Response.json({ error: "Event not found" }, { status: 404 });
  if (event.dateNeedsConfirmation) return Response.json({ error: "The flyer date or year needs confirmation. Please contact the club before adding it to your calendar." }, { status: 409 });
  if (!event.eventDate || event.isCampaign) return Response.json({ error: event.isCampaign ? "This awareness campaign has no scheduled date." : "This event does not yet have a confirmed date." }, { status: 400 });
  const content = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Rotaract PH Gateway//Club Events//EN", "CALSCALE:GREGORIAN", "METHOD:PUBLISH", "BEGIN:VEVENT", `UID:phgateway-${event.id}@club-events`, `DTSTAMP:${stamp(new Date())}`, `DTSTART:${stamp(new Date(event.eventDate))}`, `SUMMARY:${escape(event.title)}`, `LOCATION:${escape(event.location ?? "")}`, `DESCRIPTION:${escape(`${event.theme ?? event.title}\n${event.timeLabel ?? ""} WAT\n\n${event.description}\n\nOrganiser: ${event.organizer ?? ""}`)}`, "END:VEVENT", "END:VCALENDAR"].map(fold).join("\r\n") + "\r\n";
  return new Response(content, { headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": `attachment; filename="${event.slug ?? event.id}.ics"`, "Cache-Control": "no-store" } });
}
