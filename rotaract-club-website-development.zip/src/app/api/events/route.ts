import { getEvents } from "@/lib/events";
import { getStatus, todayInLagos } from "@/lib/event-display";

export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const today = todayInLagos();
    const events = (await getEvents()).map((event) => ({ ...event, status: getStatus(event, today) }));
    return Response.json({ events });
  } catch (error) { console.error("Unable to load club events:", error); return Response.json({ error: "Unable to load events." }, { status: 500 }); }
}
