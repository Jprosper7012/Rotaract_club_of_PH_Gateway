import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export const dynamic = "force-dynamic";
export async function POST(request: Request) {
  try {
    const raw = await request.text();
    if (raw.length > 12000) return Response.json({ error: "Your message is too long." }, { status: 413 });
    let body: unknown; try { body = JSON.parse(raw); } catch { return Response.json({ error: "Invalid submission." }, { status: 400 }); }
    if (!body || typeof body !== "object" || Array.isArray(body)) return Response.json({ error: "Please complete the contact form." }, { status: 400 });
    const fields = body as Record<string, unknown>;
    if (fields.website) return Response.json({ success: true });
    const value = (key: string) => typeof fields[key] === "string" ? (fields[key] as string).trim() : "";
    const name = value("name"), email = value("email").toLowerCase(), subject = value("subject"), message = value("message");
    if (name.length < 2 || name.length > 160 || email.length > 255 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !subject || subject.length > 255 || message.length < 10 || message.length > 5000) return Response.json({ error: "Please enter a valid name and email, a subject, and a message of 10–5,000 characters." }, { status: 400 });
    await db.insert(contactMessages).values({ name, email, subject, message });
    return Response.json({ success: true }, { status: 201 });
  } catch (error) { console.error("Unable to save club inquiry:", error); return Response.json({ error: "Your message could not be saved. Please try again later." }, { status: 500 }); }
}
