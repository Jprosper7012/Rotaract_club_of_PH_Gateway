"use client";
import Link from "next/link";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <><Navbar /><main id="main-content" className="container-club py-24 text-center"><Icon name="info" size={38} className="mx-auto text-[#a70942] mb-5" /><h1 className="heading mb-6">A little pause. We’ll be back.</h1><p className="text-sm text-stone-500 mb-8">We couldn’t load this page just now. Please try again.</p><div className="flex justify-center gap-4 flex-wrap"><button type="button" className="btn-club" onClick={reset}>Try again <Icon name="arrow" size={15} /></button><Link href="/" className="btn-club btn-outline">Back to home</Link></div></main><Footer /></>;
}
