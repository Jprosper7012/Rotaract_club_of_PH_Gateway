import Link from "next/link";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Icon from "@/components/icon";
import EventCard from "@/components/event-card";
import { getEvents } from "@/lib/events";
import { getStatus, todayInLagos } from "@/lib/event-display";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const allEvents = await getEvents();
  const today = todayInLagos();
  const priority = (status: string) => status === "Upcoming" ? 0 : status === "Date to confirm" ? 1 : 2;
  const featured = allEvents.filter((event) => event.isFeatured).sort((a, b) => {
    const statusA = getStatus(a, today), statusB = getStatus(b, today);
    const byStatus = priority(statusA) - priority(statusB);
    const timeA = a.eventDate ? new Date(a.eventDate).getTime() : 0;
    const timeB = b.eventDate ? new Date(b.eventDate).getTime() : 0;
    return byStatus || (statusA === "Upcoming" ? timeA - timeB : timeB - timeA);
  }).slice(0, 3);
  const fellowshipArtwork = allEvents.find((event) => event.slug === "inaugural-fellowship")?.imageUrl ?? "/events/inaugural-fellowship.svg";
  const splashArtwork = allEvents.find((event) => event.slug === "splash-out-polio")?.imageUrl ?? "/events/splash-out-polio.svg";
  const literacyArtwork = allEvents.find((event) => event.slug === "read-to-rise")?.imageUrl ?? "/events/read-to-rise.svg";
  return <><Navbar /><main id="main-content">
    <section className="home-hero"><div className="container-club hero-layout"><div className="hero-copy">
      <div className="eyebrow">Port Harcourt Gateway · People of action</div>
      <h1>Friendship.<br />Service.<br /><em>Lasting impact.</em></h1>
      <p>We’re a community of young leaders turning good intentions into meaningful action. Make friends, find your purpose, and make a difference with us.</p>
      <div className="hero-actions"><Link href="/events" className="btn-club">Explore our events <Icon name="arrow" size={15} /></Link><Link href="/about" className="link-club" style={{ color: "var(--ink)" }}>Get to know us <Icon name="diagonal" size={14} /></Link></div>
      <div className="hero-community"><div className="community-monograms" aria-hidden="true"><span>PH</span><span>RG</span><span>RI</span></div><span>Local friendship. A worldwide family.</span></div>
    </div><div className="hero-art"><Icon name="spark" className="hero-spark" size={42} /><Link href="/events/inaugural-fellowship" aria-label="Discover Inaugural Fellowship"><img className="hero-feature-art" src={fellowshipArtwork} alt="Inaugural Fellowship: Where friendships meet service" width="900" height="700" /></Link><Link href="/events/splash-out-polio" aria-label="Discover Splash Out Polio"><img className="hero-small-art" src={splashArtwork} alt="Splash Out Polio event artwork" width="900" height="700" /></Link><div className="hero-note"><Icon name="heart" size={24} style={{ color: "var(--club)" }} /><div><strong>There’s a place for you here.</strong>Come for the friendship. Stay for the impact.</div></div></div></div></section>
    <section className="values-strip" aria-label="What brings us together"><div className="container-club values-inner"><div className="value-item"><Icon name="people" size={30} /><div><h3>Friendships that matter</h3><p>Connect, grow, and belong.</p></div></div><div className="value-item"><Icon name="heart" size={30} /><div><h3>Service with purpose</h3><p>Small actions. Meaningful change.</p></div></div><div className="value-item"><Icon name="globe" size={30} /><div><h3>A global community</h3><p>Rooted in Port Harcourt. Connected worldwide.</p></div></div></div></section>
    <section className="section-club" style={{ background: "#fff" }}><div className="container-club"><div className="section-top"><div><div className="eyebrow">Together, we take action</div><h2 className="heading">Good people. Great purpose.</h2><p>Club gatherings, moments of remembrance, and initiatives that bring us together.</p></div><Link href="/events" className="link-club">View all events <Icon name="arrow" size={15} /></Link></div><div className="events-grid home-events-grid">{featured.map((event) => <EventCard key={event.id} event={event} today={today} />)}</div></div></section>
    <section className="section-club"><div className="container-club"><div className="home-story"><div className="story-art"><Link href="/events/read-to-rise"><img src={literacyArtwork} alt="Read to Rise literacy and mentorship project artwork" width="900" height="700" loading="lazy" /></Link></div><div className="story-copy"><div className="eyebrow">More than a club</div><h2 className="heading">When we come together,<br />possibilities grow.</h2><p>From conversations about better health to supporting literacy and championing a polio-free world, our community believes in showing up for what matters.</p><p>We celebrate our own club activities and the work of our partner clubs—because meaningful service is always stronger together.</p><Link href="/about" className="link-club">Our story & our purpose <Icon name="arrow" size={15} /></Link></div></div><div className="invite-banner"><div><h2>Your next chapter could start here.</h2><p>Bring your ideas, your energy, and a friend. Let’s do good together.</p></div><Link href="/contact?subject=Membership" className="btn-club">Become a member <Icon name="arrow" size={15} /></Link></div></div></section>
  </main><Footer /></>;
}
