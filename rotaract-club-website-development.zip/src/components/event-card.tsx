import Link from "next/link";
import Icon from "./icon";
import { eventDateLabel, eventLink, getStatus, type ClubEvent } from "@/lib/event-display";

export function StatusTag({ status }: { status: string }) {
  const style = status === "Upcoming" ? "status-upcoming" : status === "Date to confirm" ? "status-confirm" : status === "Campaign" ? "status-campaign" : "";
  return <span className={`status-tag ${style}`}>{status}</span>;
}

export default function EventCard({ event, today }: { event: ClubEvent; today: string }) {
  const status = getStatus(event, today);
  return <article className="event-card">
    <Link href={eventLink(event)} className="event-art" aria-label={`View ${event.title}`}><img src={event.imageUrl ?? "/events/inaugural-fellowship.svg"} alt={`${event.imageUrl?.startsWith("/uploads/") ? "Event flyer" : "Web artwork"} for ${event.title}`} width="900" height="700" loading="lazy" /></Link>
    <div className="event-card-body"><div className="event-card-tags"><span className="category-tag">{event.category}</span><StatusTag status={status} /></div><h3><Link href={eventLink(event)}>{event.title}</Link></h3><p className="event-card-description">{event.shortDescription ?? event.description.slice(0, 130)}</p><div className="event-meta"><Icon name="calendar" size={14} /><span>{eventDateLabel(event, true)}{event.dateNeedsConfirmation && event.eventDate ? " · To confirm" : ""}</span></div>{event.timeLabel && <div className="event-meta"><Icon name="clock" size={14} /><span>{event.timeLabel} WAT</span></div>}{event.location && <div className="event-meta"><Icon name={event.location.includes("Online") ? "video" : "pin"} size={14} /><span>{event.location}</span></div>}<div className="event-card-footer"><span>{event.isCampaign ? "Awareness initiative" : event.organizer === "Rotaract Club of Port Harcourt Gateway" ? "PH Gateway" : "Partner-club initiative"}</span><Link href={eventLink(event)} className="link-club">View details <Icon name="arrow" size={14} /></Link></div></div>
  </article>;
}
