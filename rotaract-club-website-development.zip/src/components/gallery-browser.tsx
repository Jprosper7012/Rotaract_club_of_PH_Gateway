"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Icon from "./icon";

export interface GalleryPhoto { id: number; title: string; imageUrl: string; caption: string | null; kind: string; credit: string | null; eventSlug: string | null; eventTitle: string | null; }

export default function GalleryBrowser({ items, initialEvent = "all" }: { items: GalleryPhoto[]; initialEvent?: string }) {
  const [kind, setKind] = useState("all");
  const [eventFilter, setEventFilter] = useState(items.some((item) => item.eventSlug === initialEvent) ? initialEvent : "all");
  const [selected, setSelected] = useState<number | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastFocused = useRef<HTMLElement | null>(null);
  const filtered = items.filter((item) => (kind === "all" || item.kind === kind) && (eventFilter === "all" || item.eventSlug === eventFilter));
  const eventOptions = [...new Map(items.filter((item) => item.eventSlug).map((item) => [item.eventSlug!, item.eventTitle!])).entries()];
  const open = selected !== null;
  const active = selected !== null ? filtered[selected] : null;

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    function keydown(e: KeyboardEvent) {
      if (e.key === "Escape") setSelected(null);
      if (e.key === "ArrowRight") setSelected((index) => index === null ? null : (index + 1) % filtered.length);
      if (e.key === "ArrowLeft") setSelected((index) => index === null ? null : (index - 1 + filtered.length) % filtered.length);
      if (e.key === "Tab") {
        const focusable = dialogRef.current?.querySelectorAll<HTMLElement>('a[href], button:not([disabled])');
        if (!focusable?.length) return;
        const first = focusable[0]; const last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    }
    document.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = previousOverflow; document.removeEventListener("keydown", keydown); lastFocused.current?.focus(); };
  }, [open, filtered.length]);

  return <><div className="browser-controls" style={{ marginBottom: 24, alignItems: "end" }}><div className="browser-tabs" role="group" aria-label="Gallery media type" style={{ margin: 0, flex: 1 }}>{[{ value: "all", label: "All moments" }, { value: "photo", label: "Photographs" }, { value: "artwork", label: "Event artwork" }].map((tab) => <button type="button" key={tab.value} className={kind === tab.value ? "active" : ""} aria-pressed={kind === tab.value} onClick={() => setKind(tab.value)}>{tab.label}<span className="tab-count">{items.filter((item) => tab.value === "all" || item.kind === tab.value).length}</span></button>)}</div><label htmlFor="gallery-event" className="sr-only">Filter gallery by event</label><select id="gallery-event" className="category-select" value={eventFilter} onChange={(e) => setEventFilter(e.target.value)}><option value="all">All events</option>{eventOptions.map(([slug, title]) => <option value={slug} key={slug}>{title}</option>)}</select></div><p aria-live="polite" className="text-[10px] text-stone-500 mb-6">{filtered.length} {filtered.length === 1 ? "item" : "items"} · Select an image to explore</p>
    {filtered.length ? <div className="gallery-grid">{filtered.map((item, index) => <button key={item.id} type="button" className="gallery-tile" onClick={(e) => { lastFocused.current = e.currentTarget; setSelected(index); }} aria-label={`Open ${item.title}`}><div className="tile-image"><img src={item.imageUrl} alt={item.title} width="900" height="700" loading="lazy" /><span className="tile-expand"><Icon name="diagonal" size={14} /></span></div><div className="tile-info"><small>{item.kind === "photo" ? "Outreach photograph" : item.imageUrl.startsWith("/uploads/") ? "Original event flyer" : "Adapted event artwork"}</small><h3>{item.title}</h3><p>{item.caption}</p></div></button>)}</div> : <div className="empty-club"><Icon name="image" size={34} /><h3>{kind === "photo" ? "The photo album is still to come." : "No images in this selection"}</h3><p>{kind === "photo" ? "Original outreach photograph files have not yet been imported. The event artwork and information are available to explore." : "Choose another event or media type to explore the gallery."}</p><button type="button" className="btn-club" onClick={() => { setKind("all"); setEventFilter("all"); }}>Explore all artwork <Icon name="arrow" size={15} /></button></div>}
    {active && <div ref={dialogRef} className="lightbox" role="dialog" aria-modal="true" aria-labelledby="gallery-dialog-title" onClick={(e) => { if (e.target === e.currentTarget) setSelected(null); }}><button ref={closeRef} type="button" className="lightbox-close" onClick={() => setSelected(null)} aria-label="Close image"><Icon name="close" size={21} /></button>{filtered.length > 1 && <button type="button" className="lightbox-prev" onClick={() => setSelected((index) => (index! - 1 + filtered.length) % filtered.length)} aria-label="Previous image"><Icon name="back" size={21} /></button>}<div className="lightbox-panel"><img className="lightbox-image" src={active.imageUrl} alt={active.title} width="900" height="700" /><div className="lightbox-caption"><h2 id="gallery-dialog-title">{active.title}</h2><p>{active.caption}</p><p style={{ marginTop: 8, fontSize: 10 }}>{active.credit}</p><div className="flex justify-between items-center gap-4">{active.eventSlug && <Link href={`/events/${active.eventSlug}`} className="link-club">About this event <Icon name="arrow" size={14} /></Link>}<span className="text-[10px] text-stone-400">{selected! + 1} / {filtered.length}</span></div></div></div>{filtered.length > 1 && <button type="button" className="lightbox-next" onClick={() => setSelected((index) => (index! + 1) % filtered.length)} aria-label="Next image"><Icon name="arrow" size={21} /></button>}</div>}
  </>;
}
