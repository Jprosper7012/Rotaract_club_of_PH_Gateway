"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import Brand from "./brand";
import Icon from "./icon";

const links = [{ name: "Home", href: "/" }, { name: "About us", href: "/about" }, { name: "Events", href: "/events" }, { name: "Gallery", href: "/gallery" }, { name: "Our people", href: "/members" }, { name: "Contact", href: "/contact" }];

export default function Navbar() {
  const path = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const active = (href: string) => href === "/" ? path === href : path.startsWith(href);
  return <>
    <a href="#main-content" className="skip-link">Skip to content</a>
    <div className="utility-bar"><div className="container-club"><span>People of action. A community of friends.</span><div className="utility-right"><span>Port Harcourt, Nigeria</span><a href="https://www.instagram.com/rcphgateway/" target="_blank" rel="noreferrer"><Icon name="instagram" size={12} /> @rcphgateway</a></div></div></div>
    <header className="club-nav"><div className="container-club nav-inner">
      <Link href="/" aria-label="Rotaract Club of Port Harcourt Gateway home" onClick={() => setMenuOpen(false)}><Brand /></Link>
      <nav className="nav-links" aria-label="Main navigation">{links.map((link) => <Link key={link.href} href={link.href} className={active(link.href) ? "active" : ""} aria-current={active(link.href) ? "page" : undefined}>{link.name}</Link>)}</nav>
      <Link href="/contact?subject=Membership" className="btn-club nav-join">Join the club <Icon name="arrow" size={13} /></Link>
      <button className="mobile-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(!menuOpen)}><Icon name={menuOpen ? "close" : "menu"} size={21} /></button>
    </div>{menuOpen && <nav id="mobile-navigation" className="mobile-navigation" aria-label="Mobile navigation">{links.map((link) => <Link key={link.href} href={link.href} className={active(link.href) ? "active" : ""} aria-current={active(link.href) ? "page" : undefined} onClick={() => setMenuOpen(false)}>{link.name}</Link>)}<Link href="/contact?subject=Membership" onClick={() => setMenuOpen(false)}>Become a member <span aria-hidden="true">↗</span></Link></nav>}</header>
  </>;
}
