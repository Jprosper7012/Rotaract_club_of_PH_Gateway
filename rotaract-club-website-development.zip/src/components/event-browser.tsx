"use client";

import { useState } from "react";
import Link from "next/link";
import EventCard from "./event-card";
import Icon from "./icon";
import { getStatus, type ClubEvent } from "@/lib/event-display";

type Tab = "all" | "upcoming" | "past" | "to-confirm" | "campaigns";
const tabs: { value: Tab; label: string }[] = [{ value: "all", label: "All events" }, { value: "upcoming", label: "Upcoming" }, { value: "past", label: "Past events" }, { value: "to-confirm", label: "To confirm" }, { value: "campaigns", label: "Campaigns" }];

export default function EventBrowser({ events, today, initialStatus = "all" }: { events: ClubEvent[]; today: string; initialStatus?: string }) {
  const [tab, setTab] = useState<Tab>(tabs.some((t) => t.value === initialStatus) ? initialStatus as Tab : "all");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All categories");
  const matchesTab = (event: ClubEvent, value: Tab) => value === "all" || (value === "upcoming" && getStatus(event, today) === "Upcoming") || (value === "past" && getStatus(event, today) === "Past event") || (value === "to-confirm" && getStatus(event, today) === "Date to confirm") || (value === "campaigns" && event.isCampaign);
  const counts = Object.fromEntries(tabs.map((item) => [item.value, events.filter((event) => matchesTab(event, item.value)).length]));
  const categories = [...new Set(events.map((event) => event.category))].sort();
  const filtered = events.filter((event) => matchesTab(event, tab) && (category === "All categories" || event.category === category) && `${event.title} ${event.theme ?? ""} ${event.description} ${event.sourceDateLabel ?? ""} ${event.location ?? ""} ${event.organizer ?? ""}`.toLowerCase().includes(query.trim().toLowerCase())).sort((a, b) => (b.eventDate ? new Date(b.eventDate).getTime() : 0) - (a.eventDate ? new Date(a.eventDate).getTime() : 0));
  const noUpcomingDates = tab === "upcoming" && counts.upcoming === 0 && !query && category === "All categories";
  function reset() { setQuery(""); setCategory("All categories"); setTab("all"); }

  return <div className="event-browser"><div className="browser-tabs" role="group" aria-label="Filter by event status">{tabs.map((item) => <button key={item.value} type="button" className={tab === item.value ? "active" : ""} aria-pressed={tab === item.value} onClick={() => setTab(item.value)}>{item.label}<span className="tab-count">{counts[item.value]}</span></button>)}</div>
    <div className="browser-controls"><div className="search-box"><Icon name="search" size={17} /><label htmlFor="event-search" className="sr-only">Search events</label><input id="event-search" type="search" placeholder="Search events, themes, or locations..." value={query} onChange={(e) => setQuery(e.target.value)} /></div><label htmlFor="event-category" className="sr-only">Event category</label><select id="event-category" className="category-select" value={category} onChange={(e) => setCategory(e.target.value)}><option>All categories</option>{categories.map((item) => <option key={item}>{item}</option>)}</select></div>
    <div className="results-line"><span aria-live="polite">Showing {filtered.length} {filtered.length === 1 ? "event or initiative" : "events & initiatives"}</span>{(query || category !== "All categories" || tab !== "all") && <button type="button" onClick={reset}>Clear filters</button>}</div>
    {filtered.length ? <div className="events-grid">{filtered.map((event) => <EventCard key={event.id} event={event} today={today} />)}</div> : <div className="empty-club"><Icon name="calendar" size={35} /><h3>{noUpcomingDates ? "More good things are on the way." : "No matching events"}</h3><p>{noUpcomingDates ? "There are no confirmed upcoming dates at the moment. Explore our past events or get in touch to join our next chapter." : "Try another search or category to discover our events and initiatives."}</p><div className="flex flex-wrap justify-center gap-4"><button type="button" className="btn-club" onClick={reset}>Explore all events <Icon name="arrow" size={15} /></button><Link href="/contact" className="btn-club btn-outline">Contact the club</Link></div></div>}
    <div className="source-note" style={{ marginTop: 30 }}><Icon name="info" size={16} /><p>Dates, times, and organiser credits follow the supplied flyers. All times are West Africa Time (WAT). An incomplete event date is marked for confirmation; undated awareness material is listed separately as a campaign.</p></div>
  </div>;
}
