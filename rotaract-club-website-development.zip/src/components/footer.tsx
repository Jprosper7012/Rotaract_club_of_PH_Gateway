import Link from "next/link";
import Brand from "./brand";
import Icon from "./icon";

export default function Footer() {
  return <footer className="club-footer"><div className="container-club">
    <div className="footer-main"><div className="footer-intro"><Link href="/" aria-label="Club home"><Brand light /></Link><p>Young leaders. Lifelong friends. A shared purpose.<br />Together, we’re creating lasting impact in Port Harcourt and beyond.</p></div>
      <div><h3>Explore the club</h3><div className="footer-links"><Link href="/about">About us</Link><Link href="/events">Events & initiatives</Link><Link href="/gallery">Our gallery</Link><Link href="/members">Our people</Link><Link href="/contact">Get in touch</Link></div></div>
      <div><h3>Let’s stay connected</h3><div className="footer-contact"><p>Port Harcourt, Rivers State<br />Nigeria</p><Link href="/contact" className="link-club" style={{ color: "#f2aec5" }}>Send the club a message <Icon name="arrow" size={13} /></Link><div className="footer-social"><a href="https://www.instagram.com/rcphgateway/" target="_blank" rel="noreferrer" aria-label="Club Instagram"><Icon name="instagram" size={18} /></a><a href="https://www.facebook.com/rcphgateway/" target="_blank" rel="noreferrer" aria-label="Club Facebook"><Icon name="facebook" size={18} /></a><span>@rcphgateway</span></div></div></div>
    </div><div className="footer-bottom"><p>© {new Date().getFullYear()} Rotaract Club of Port Harcourt Gateway. All rights reserved.</p><p>Service above self. Friendship for life.</p></div>
  </div></footer>;
}
