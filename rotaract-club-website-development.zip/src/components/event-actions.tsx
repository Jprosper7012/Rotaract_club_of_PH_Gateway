"use client";

import { useState, type FormEvent } from "react";
import Icon from "./icon";

export function ShareEvent() {
  const [message, setMessage] = useState("");
  async function share() {
    try {
      if (!navigator.clipboard) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(window.location.href);
      setMessage("Event link copied!");
    } catch { setMessage("Copy the link from your browser’s address bar to share this event."); }
  }
  return <><button className="btn-club btn-outline" type="button" onClick={share}><Icon name="share" size={15} /> Share this event</button>{message && <p role="status">{message}</p>}</>;
}

export function EventRegistration({ eventId }: { eventId: number }) {
  const [state, setState] = useState<"idle" | "sending" | "success">("idle");
  const [message, setMessage] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    setState("sending"); setMessage("");
    try {
      const response = await fetch(`/api/events/${eventId}/register`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: data.get("name"), email: data.get("email") }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? "Unable to save your interest. Please try again.");
      setState("success"); setMessage(body.alreadyRegistered ? "You’ve already registered your interest in this event." : "Your interest has been registered. Follow @rcphgateway or contact the club for the latest arrangements.");
    } catch (error) { setState("idle"); setMessage(error instanceof Error ? error.message : "Please try again."); }
  }
  if (state === "success") return <div className="form-success"><Icon name="check" size={32} /><h3>You’re on the list.</h3><p role="status">{message}</p></div>;
  return <form onSubmit={submit} className="form-club"><h3 className="text-base font-semibold">Register your interest</h3><div><label htmlFor="rsvp-name">Full name</label><input id="rsvp-name" name="name" required autoComplete="name" minLength={2} maxLength={160} placeholder="Your full name" /></div><div><label htmlFor="rsvp-email">Email address</label><input id="rsvp-email" name="email" type="email" required autoComplete="email" maxLength={255} placeholder="you@example.com" /></div><p className="text-[10px] text-stone-500 leading-relaxed">Your details are saved for this event only. This is an expression of interest, not a paid ticket or a confirmation email.</p><button type="submit" className="btn-club" disabled={state === "sending"}>{state === "sending" ? "Saving..." : "Register interest"}<Icon name="arrow" size={15} /></button>{message && <p role="alert" className="form-error">{message}</p>}</form>;
}
