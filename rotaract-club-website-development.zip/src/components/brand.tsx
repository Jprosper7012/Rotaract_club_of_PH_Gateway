import { useId } from "react";

export function RotaryWheel({ className = "" }: { className?: string }) {
  const id = useId().replaceAll(":", "");
  return <svg viewBox="0 0 100 100" fill="none" className={className} aria-hidden="true">
    <g fill="currentColor">{Array.from({ length: 24 }, (_, i) => <rect key={i} x="46.5" y="2" width="7" height="13" rx="1.7" transform={`rotate(${i * 15} 50 50)`} />)}</g>
    <circle cx="50" cy="50" r="38" stroke="currentColor" strokeWidth="5" /><circle cx="50" cy="50" r="28" stroke="currentColor" strokeWidth="2.4" />
    <g stroke="currentColor" strokeWidth="4">{Array.from({ length: 6 }, (_, i) => <path key={i} d="M50 22v19" transform={`rotate(${i * 60} 50 50)`} />)}</g>
    <circle cx="50" cy="50" r="10" stroke="currentColor" strokeWidth="3" /><circle cx="50" cy="50" r="5" fill="currentColor" />
    <defs><path id={`${id}top`} d="M17 51a33 33 0 0 1 66 0" /><path id={`${id}bottom`} d="M13 52a37 37 0 0 0 74 0" /></defs>
    <text fill="currentColor" fontSize="8" fontWeight="700" letterSpacing="1.4" fontFamily="Arial, sans-serif"><textPath href={`#${id}top`} startOffset="50%" textAnchor="middle">ROTARY</textPath></text>
    <text fill="currentColor" fontSize="6.5" fontWeight="700" letterSpacing=".5" fontFamily="Arial, sans-serif"><textPath href={`#${id}bottom`} startOffset="50%" textAnchor="middle">INTERNATIONAL</textPath></text>
  </svg>;
}

export default function Brand({ light = false }: { light?: boolean }) {
  return <span className={`club-brand ${light ? "club-brand-light" : ""}`}><span className="brand-top">Rotaract<RotaryWheel className="brand-wheel" /></span><span className="brand-bottom">Club of Port Harcourt Gateway</span></span>;
}
