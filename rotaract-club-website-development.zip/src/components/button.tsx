import { ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "outline" | "ghost";
  className?: string;
}

const variants = {
  primary:
    "bg-rotaract-blue text-white px-4 py-2.5 rounded-lg font-medium hover:bg-rotaract-blue-dark transition-colors shadow-md shadow-rotaract-blue/20",
  outline:
    "border border-slate-300 bg-white text-slate-700 px-4 py-2.5 rounded-lg font-medium hover:bg-slate-50 hover:text-slate-900 transition-colors",
  ghost:
    "text-slate-600 px-4 py-2.5 rounded-lg font-medium hover:bg-slate-100 hover:text-slate-900 transition-colors",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", className, ...props }, ref) => (
    <button
      ref={ref}
      className={`${variants[variant]} ${className}`}
      {...props}
    />
  )
);

Button.displayName = "Button";
