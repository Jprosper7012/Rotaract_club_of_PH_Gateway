interface GalleryCardProps {
  id: number;
  title: string;
  imageUrl: string;
  caption?: string | null;
}

export default function GalleryCard({
  id,
  title,
  imageUrl,
  caption,
}: GalleryCardProps) {
  return (
    <article className="group rounded-xl overflow-hidden border border-slate-200 bg-white hover:shadow-xl transition-all duration-300">
      <div className="relative h-64 overflow-hidden">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
          <div className="text-white text-sm font-medium bg-black/60 px-3 py-1 rounded-full backdrop-blur-sm">
            {title}
          </div>
        </div>
      </div>
      {caption && (
        <div className="p-4">
          <p className="text-sm text-slate-600">{caption}</p>
        </div>
      )}
    </article>
  );
}
