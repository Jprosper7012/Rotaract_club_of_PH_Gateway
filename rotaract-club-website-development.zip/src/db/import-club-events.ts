import "dotenv/config";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { and, eq, inArray } from "drizzle-orm";
import { db, pool } from "@/db";
import { events, gallery, members } from "@/db/schema";
import { clubEventData, outreachPhotoData } from "@/lib/club-event-data";

async function importEvents() {
  let importedPhotos = 0;
  await db.transaction(async (tx) => {
    await tx.delete(gallery).where(inArray(gallery.title, ["Health Outreach 2025", "Leadership Summit", "Waterfront Cleanup", "School Supply Drive", "Community Meeting"]));
    await tx.delete(events).where(inArray(events.title, ["Community Health Outreach", "Youth Leadership Summit", "Environmental Cleanup Drive", "Back to School Drive", "Food Security Program"]));
    await tx.delete(members).where(inArray(members.email, ["amina.ibrahim@rotaractphgateway.org", "chinedu.okafor@rotaractphgateway.org", "zainab.suleiman@rotaractphgateway.org", "david.peters@rotaractphgateway.org", "grace.eze@rotaractphgateway.org"]));

    for (const data of clubEventData) {
      const originalPoster = `/uploads/${data.slug}.jpg`;
      const values = {
        ...data,
        sourceDateLabel: data.sourceDateLabel ?? null,
        imageUrl: existsSync(join(process.cwd(), "public", originalPoster)) ? originalPoster : data.imageUrl,
        isPast: data.eventDate ? data.eventDate.getTime() < Date.now() : false,
      };
      const [event] = await tx.insert(events).values(values).onConflictDoUpdate({ target: events.slug, set: values }).returning();
      const [existing] = await tx.select().from(gallery).where(and(eq(gallery.eventId, event.id), eq(gallery.kind, "artwork"))).limit(1);
      const art = { title: data.title, imageUrl: values.imageUrl, eventId: event.id, kind: "artwork", caption: data.theme, credit: values.imageUrl === originalPoster ? "Original event flyer supplied by the club. Organiser credit follows the flyer." : "Web artwork adapted from the supplied event flyer. Event and organiser details are transcribed from that flyer." };
      if (existing) await tx.update(gallery).set(art).where(eq(gallery.id, existing.id));
      else await tx.insert(gallery).values(art);

      for (const photo of outreachPhotoData.filter((item) => item.eventSlug === data.slug)) {
        if (!existsSync(join(process.cwd(), "public", photo.file))) continue;
        const [present] = await tx.select().from(gallery).where(eq(gallery.imageUrl, photo.file)).limit(1);
        const photoValues = { title: photo.title, imageUrl: photo.file, eventId: event.id, caption: photo.caption, kind: "photo", credit: photo.credit };
        if (present) await tx.update(gallery).set(photoValues).where(eq(gallery.id, present.id));
        else { await tx.insert(gallery).values(photoValues); importedPhotos++; }
      }
    }

    const leaders = [
      { name: "Johnson Odinaka Prosper", position: "President · 2026/2027 Rotary Year", bio: "Named as incoming president in the club’s Handing Over Ceremony flyer. Theme: Create Lasting Impact! Also listed as host of the Health Talk session." },
      { name: "Oko-Jaja Amarachi", position: "President · 2025/2026 Rotary Year", bio: "Recognised as outgoing president in the club’s Handing Over Ceremony flyer. Theme: Unite for Good." },
    ];
    for (const leader of leaders) {
      const [present] = await tx.select().from(members).where(eq(members.name, leader.name)).limit(1);
      if (present) await tx.update(members).set(leader).where(eq(members.id, present.id));
      else await tx.insert(members).values(leader);
    }
  });
  console.log(`Imported ${clubEventData.length} distinct flyer-based events/campaigns, organiser credits, web artwork, and 2 verified leadership profiles. Duplicate flyers are not imported twice.`);
  console.log(`Added ${importedPhotos} original photographs from available files. Original files in public/uploads are imported only when present; no stock photos are substituted.`);
}

importEvents().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => pool.end());
