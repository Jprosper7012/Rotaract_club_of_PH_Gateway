import { relations } from "drizzle-orm";
import { pgTable, serial, text, varchar, timestamp, boolean, integer, uniqueIndex } from "drizzle-orm/pg-core";

export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  position: varchar("position", { length: 255 }).notNull(),
  bio: text("bio"),
  imageUrl: varchar("image_url", { length: 500 }),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  joinDate: timestamp("join_date").defaultNow(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  shortDescription: varchar("short_description", { length: 500 }),
  eventDate: timestamp("event_date"),
  sourceDateLabel: varchar("source_date_label", { length: 160 }),
  timeLabel: varchar("time_label", { length: 120 }),
  location: varchar("location", { length: 255 }),
  imageUrl: varchar("image_url", { length: 500 }),
  category: varchar("category", { length: 80 }).notNull().default("Community service"),
  theme: varchar("theme", { length: 255 }),
  organizer: text("organizer"),
  partners: text("partners"),
  sourceNote: text("source_note"),
  dateNeedsConfirmation: boolean("date_needs_confirmation").notNull().default(false),
  isCampaign: boolean("is_campaign").notNull().default(false),
  isFeatured: boolean("is_featured").default(false),
  isPast: boolean("is_past").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const gallery = pgTable("gallery", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  imageUrl: varchar("image_url", { length: 500 }).notNull(),
  eventId: integer("event_id").references(() => events.id, { onDelete: "set null" }),
  caption: text("caption"),
  kind: varchar("kind", { length: 30 }).notNull().default("photo"),
  credit: text("credit"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  isRead: boolean("is_read").default(false),
});

export const eventRegistrations = pgTable("event_registrations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [uniqueIndex("event_registration_email_idx").on(table.eventId, table.email)]);

export const eventsRelations = relations(events, ({ many }) => ({
  gallery: many(gallery),
  registrations: many(eventRegistrations),
}));

export const galleryRelations = relations(gallery, ({ one }) => ({
  event: one(events, { fields: [gallery.eventId], references: [events.id] }),
}));

export const registrationRelations = relations(eventRegistrations, ({ one }) => ({
  event: one(events, { fields: [eventRegistrations.eventId], references: [events.id] }),
}));
