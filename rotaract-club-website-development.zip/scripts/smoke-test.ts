import "dotenv/config";
import assert from "node:assert/strict";
import { and, eq } from "drizzle-orm";
import { db, pool } from "@/db";
import { contactMessages, eventRegistrations, events } from "@/db/schema";
import { clubEventData } from "@/lib/club-event-data";

const base = process.env.TEST_BASE_URL ?? "http://localhost:3000";
const jsonPost = (path: string, data: unknown) => fetch(`${base}${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
let temporaryEventId: number | undefined;
const testEmail = `club-smoke-${Date.now()}@example.com`;

async function test() {
  const health = await fetch(`${base}/api/health`);
  assert.equal(health.status, 200); assert.equal((await health.json()).ok, true);
  const response = await fetch(`${base}/api/events`);
  assert.equal(response.status, 200);
  const { events: records } = await response.json();
  assert.equal(records.length, clubEventData.length);
  assert.equal(new Set(records.map((item: { slug: string }) => item.slug)).size, clubEventData.length);
  for (const source of clubEventData) {
    const event = records.find((item: { slug: string }) => item.slug === source.slug);
    assert(event, `Missing ${source.slug}`);
    const page = await fetch(`${base}/events/${source.slug}`); assert.equal(page.status, 200, source.slug);
    const text = await page.text(); assert(text.includes(event.title));
    const image = await fetch(`${base}${event.imageUrl}`); assert.equal(image.status, 200); assert(image.headers.get("content-type")?.startsWith("image/"));
  }
  const find = (slug: string) => records.find((item: { slug: string }) => item.slug === slug);
  assert.equal(find("end-polio-now").eventDate, null); assert.equal(find("end-polio-now").status, "Campaign");
  assert.equal(find("handing-over-ceremony").dateNeedsConfirmation, true); assert.equal(find("handing-over-ceremony").status, "Date to confirm");
  assert(find("health-talk-your-health-your-wealth").eventDate.startsWith("2025-06-21"));
  assert.equal(find("splash-out-polio").organizer, "Rotaract Club of Rivers New City");
  assert.equal(find("read-to-rise").organizer, "Rotaract Club of Port Harcourt");
  const memorial = find("memorial-fellowship");
  assert.equal(memorial.eventDate, "2026-11-14T15:30:00.000Z");
  assert.equal(memorial.dateNeedsConfirmation, false);
  assert(memorial.description.includes("Ubochi Chinweoke Gloria (1997–2023)"));
  assert.equal(memorial.timeLabel, "4:00 PM for 4:30 PM");
  const enisc = find("enisc-bee-2");
  assert.equal(enisc.eventDate, null); assert.equal(enisc.isCampaign, false); assert.equal(enisc.status, "Date to confirm");
  assert.equal(enisc.sourceDateLabel, "7 November · Year not stated");
  assert.equal(enisc.timeLabel, "9:00 AM prompt");
  assert.equal(enisc.organizer, "Rotaract Club of Port Harcourt Cosmopolitan Hybride");
  for (const detail of ["JSS1–JSS3", "₦100,000", "₦70,000", "₦50,000", "08136567556", "08029226150", "eniscbee@gmail.com"]) assert(enisc.description.includes(detail), detail);
  const eniscHtml = await (await fetch(`${base}/events/enisc-bee-2`)).text();
  const eniscSidebar = eniscHtml.match(/<aside[\s\S]*?<\/aside>/)?.[0] ?? "";
  assert(eniscSidebar.includes("Year not stated")); assert(!eniscSidebar.includes("Ongoing awareness campaign"));
  assert(!eniscSidebar.includes("Download calendar event")); assert(!eniscSidebar.includes("rsvp-name"));
  for (const path of ["/", "/events", "/events?status=to-confirm", "/about", "/gallery", "/gallery?event=read-to-rise", "/gallery?event=enisc-bee-2", "/members", "/contact?subject=Membership"]) assert.equal((await fetch(`${base}${path}`)).status, 200, path);
  const homeHtml = await (await fetch(`${base}/`)).text(); assert(homeHtml.includes("Memorial Fellowship")); assert(homeHtml.includes("ENISC Bee 2.0"));
  assert.equal((await fetch(`${base}/events/nonexistent-club-event`)).status, 404);
  assert.equal((await fetch(`${base}/events/999999999999999999999999`)).status, 404);
  for (const [slug, start] of [["splash-out-polio", "20261017T120000Z"], ["memorial-fellowship", "20261114T153000Z"]]) {
    const calendar = await fetch(`${base}/api/events/${slug}/calendar`);
    assert.equal(calendar.status, 200); assert(calendar.headers.get("content-type")?.includes("text/calendar"));
    const text = await calendar.text(); assert(text.includes(`DTSTART:${start}`)); assert(text.includes("BEGIN:VEVENT"));
    for (const line of text.split("\r\n")) assert(Buffer.byteLength(line, "utf8") <= 75, "Calendar content line exceeds 75 bytes");
  }
  for (const slug of ["handing-over-ceremony", "enisc-bee-2"]) assert.equal((await fetch(`${base}/api/events/${slug}/calendar`)).status, 409);
  assert.equal((await fetch(`${base}/api/events/end-polio-now/calendar`)).status, 400);
  assert.equal((await jsonPost("/api/contact", { name: "A", email: "invalid", subject: "Test", message: "x" })).status, 400);
  assert.equal((await fetch(`${base}/api/contact`, { method: "POST", body: "not-json" })).status, 400);
  assert.equal((await jsonPost("/api/contact", { name: "Club smoke test", email: testEmail, subject: "Automated validation", message: "Testing that contact inquiries are saved correctly." })).status, 201);
  const saved = await db.select().from(contactMessages).where(eq(contactMessages.email, testEmail)); assert.equal(saved.length, 1);
  for (const slug of ["health-talk-your-health-your-wealth", "handing-over-ceremony", "end-polio-now", "enisc-bee-2"]) assert.equal((await jsonPost(`/api/events/${slug}/register`, { name: "Club smoke test", email: testEmail })).status, 409);
  const [future] = await db.insert(events).values({ slug: `smoke-test-${Date.now()}`, title: "Temporary automated validation event", description: "This record is removed by the smoke test.", eventDate: new Date(Date.now() + 7 * 86400000), category: "Fellowship" }).returning();
  temporaryEventId = future.id;
  const firstRegistration = await jsonPost(`/api/events/${future.id}/register`, { name: "Club smoke test", email: testEmail }); assert.equal(firstRegistration.status, 201);
  const duplicate = await jsonPost(`/api/events/${future.id}/register`, { name: "Club smoke test", email: testEmail }); assert.equal(duplicate.status, 200); assert.equal((await duplicate.json()).alreadyRegistered, true);
  const registrations = await db.select().from(eventRegistrations).where(and(eq(eventRegistrations.eventId, future.id), eq(eventRegistrations.email, testEmail))); assert.equal(registrations.length, 1);
  const profiles = (await (await fetch(`${base}/api/members`)).json()).members; assert.equal(profiles.length, 2); assert(!("phone" in profiles[0])); assert(!("email" in profiles[0]));
  const galleryItems = (await (await fetch(`${base}/api/gallery`)).json()).gallery;
  for (const source of clubEventData) assert.equal(galleryItems.filter((item: { title: string; kind: string }) => item.title === source.title && item.kind === "artwork").length, 1, `Duplicate gallery artwork: ${source.title}`);
  console.log(`PASS: ${clubEventData.length} unique events; memorial tribute/date/time and WAT calendar; ENISC eligibility/prizes/credits; unknown-year guards; homepage features; galleries; inquiry persistence; registration deduplication.`);
}

async function main() {
  try { await test(); }
  finally { await db.delete(contactMessages).where(eq(contactMessages.email, testEmail)); await db.delete(eventRegistrations).where(eq(eventRegistrations.email, testEmail)); if (temporaryEventId) await db.delete(events).where(eq(events.id, temporaryEventId)); await pool.end(); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
