import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';

// Use an installed Playwright module or an isolated PLAYWRIGHT_MODULE path.
// Set CAPTURE_SCREENSHOTS=1 to also save responsive screenshots under .validation/.
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE ?? 'playwright');
const base = process.env.TEST_BASE_URL ?? 'http://localhost:3000';
const screenshots = process.env.CAPTURE_SCREENSHOTS === '1';
if (screenshots) await mkdir('.validation', { recursive: true });
const { events } = await (await fetch(`${base}/api/events`)).json();
const { gallery } = await (await fetch(`${base}/api/gallery`)).json();
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
const noOverflow = async (label) => assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `Horizontal overflow: ${label}`);
const cardCount = (count) => page.waitForFunction((expected) => document.querySelectorAll('.event-card').length === expected, count);

try {
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.locator('img').evaluateAll((images) => images.forEach((image) => { image.loading = 'eager'; }));
  await page.waitForFunction(() => [...document.images].every((image) => image.complete && image.naturalWidth > 0));
  await noOverflow('desktop home');
  const featured = await page.locator('.home-events-grid h3').allTextContents();
  assert(featured.includes('Memorial Fellowship')); assert(featured.includes('ENISC Bee 2.0'));
  if (screenshots) await page.screenshot({ path: '.validation/home-desktop.png', fullPage: true });

  await page.goto(`${base}/events`, { waitUntil: 'networkidle' });
  await cardCount(events.length);
  await page.getByRole('button', { name: /^Campaigns/ }).click();
  await cardCount(events.filter((event) => event.isCampaign).length);
  assert.equal(await page.locator('.event-card h3').innerText(), 'End Polio Now');
  await page.getByRole('button', { name: /^All events/ }).click();
  await cardCount(events.length);
  await page.getByLabel('Event category').selectOption('Education');
  await cardCount(events.filter((event) => event.category === 'Education').length);
  assert((await page.locator('.event-card h3').allTextContents()).includes('ENISC Bee 2.0'));
  await page.getByLabel('Event category').selectOption('All categories');
  await page.getByRole('searchbox', { name: 'Search events' }).fill('City Express');
  await cardCount(events.filter((event) => event.location?.includes('City Express')).length);
  await page.getByRole('searchbox', { name: 'Search events' }).fill('no-matching-club-event');
  await cardCount(0);
  assert(await page.getByRole('heading', { name: 'No matching events' }).isVisible());
  await page.getByRole('button', { name: 'Clear filters' }).click();
  await cardCount(events.length);
  await page.getByRole('button', { name: /^Upcoming/ }).click();
  const upcoming = events.filter((event) => event.status === 'Upcoming');
  await cardCount(upcoming.length);
  if (!upcoming.length) assert(await page.getByRole('heading', { name: 'More good things are on the way.' }).isVisible());
  await page.getByRole('button', { name: /^To confirm/ }).click();
  await cardCount(events.filter((event) => event.status === 'Date to confirm').length);
  const eniscCard = page.locator('.event-card').filter({ has: page.getByRole('heading', { name: 'ENISC Bee 2.0', exact: true }) });
  assert((await eniscCard.innerText()).includes('7 November · Year not stated'));
  assert(!(await eniscCard.innerText()).includes('Ongoing awareness campaign'));
  await page.getByRole('button', { name: /^All events/ }).click();
  await cardCount(events.length);
  if (screenshots) await page.screenshot({ path: '.validation/events-desktop.png', fullPage: true });

  await page.goto(`${base}/gallery`, { waitUntil: 'networkidle' });
  assert.equal(await page.locator('.gallery-tile').count(), gallery.length);
  await page.getByRole('button', { name: 'Open ENISC Bee 2.0', exact: true }).click();
  await page.getByRole('dialog').waitFor({ state: 'visible' });
  assert.equal(await page.locator('#gallery-dialog-title').innerText(), 'ENISC Bee 2.0');
  await page.keyboard.press('ArrowRight');
  await page.waitForFunction(() => document.querySelector('#gallery-dialog-title')?.textContent !== 'ENISC Bee 2.0');
  await page.keyboard.press('Escape');
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  assert.equal(await page.evaluate(() => document.activeElement?.getAttribute('aria-label')), 'Open ENISC Bee 2.0');

  await page.goto(`${base}/events/memorial-fellowship`, { waitUntil: 'networkidle' });
  assert(await page.getByRole('heading', { name: 'In loving memory', exact: true }).isVisible());
  const memorialDetails = await page.locator('.detail-sidebar').innerText();
  assert(memorialDetails.includes('14 November 2026')); assert(memorialDetails.includes('4:00 PM for 4:30 PM WAT'));
  assert.equal(await page.getByRole('link', { name: 'Download calendar event' }).count(), 1);
  if (screenshots) await page.screenshot({ path: '.validation/memorial-desktop.png', fullPage: true });

  await page.goto(`${base}/events/enisc-bee-2`, { waitUntil: 'networkidle' });
  assert(await page.getByText('Please confirm the date with the club', { exact: true }).isVisible());
  assert.equal(await page.getByRole('link', { name: 'Download calendar event' }).count(), 0);
  assert.equal(await page.locator('#rsvp-name').count(), 0);
  await page.getByRole('link', { name: 'Confirm the event date' }).click();
  await page.waitForURL('**/contact?subject=*');
  assert.equal(await page.getByLabel('What’s on your mind?').inputValue(), 'Date confirmation: ENISC Bee 2.0');

  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto(base, { waitUntil: 'networkidle' });
  await noOverflow('mobile home');
  await page.getByRole('button', { name: 'Open navigation' }).click();
  const mobileNav = page.getByRole('navigation', { name: 'Mobile navigation' });
  assert(await mobileNav.isVisible());
  await mobileNav.getByRole('link', { name: 'Events', exact: true }).click();
  await page.waitForURL('**/events');
  await cardCount(events.length);
  await noOverflow('mobile events');
  await page.goto(`${base}/events/memorial-fellowship`, { waitUntil: 'networkidle' });
  await noOverflow('mobile memorial');
  if (screenshots) await page.screenshot({ path: '.validation/memorial-mobile.png', fullPage: true });
  await page.goto(`${base}/events/enisc-bee-2`, { waitUntil: 'networkidle' });
  await noOverflow('mobile ENISC');
  if (screenshots) await page.screenshot({ path: '.validation/enisc-mobile.png', fullPage: true });

  await page.goto(`${base}/contact?subject=Membership`, { waitUntil: 'networkidle' });
  assert.equal(await page.getByLabel('What’s on your mind?').inputValue(), 'Membership');
  await page.getByLabel('Full name').fill('Automated browser validation');
  await page.getByLabel('Email address').fill(`club-browser-validation-${Date.now()}@example.com`);
  await page.getByLabel('Your message').fill('Testing that the mobile membership contact form saves a valid inquiry.');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  await page.getByRole('heading', { name: 'Thank you for reaching out.' }).waitFor();
  await noOverflow('mobile contact');
  assert.equal(errors.length, 0, `Browser errors: ${errors.join('; ')}`);
  console.log(`PASS: ${events.length} event covers; homepage additions; filters; ENISC unknown-year safeguards; memorial details; accessible gallery; desktop/mobile layouts; contact submission. No browser/hydration errors.`);
} finally { await browser.close(); }
